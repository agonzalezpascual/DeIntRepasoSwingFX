Help content generated for JavaFX
